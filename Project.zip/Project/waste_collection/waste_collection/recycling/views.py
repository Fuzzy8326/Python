from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import WasteCollection
from .forms import WasteCollectionForm

# ------------------------------
# LIST VIEW – Show all collections
# ------------------------------
class CollectionListView(ListView):
    model = WasteCollection  # The model to retrieve data from
    template_name = 'recycling/collection_list.html'  # Template to render
    context_object_name = 'collections'  # Name used to access items in template
    paginate_by = 10  # Paginate results (10 per page)

# ------------------------------
# DETAIL VIEW – Show a single collection record
# ------------------------------
class CollectionDetailView(DetailView):
    model = WasteCollection
    template_name = 'recycling/collection_detail.html'
    context_object_name = 'collection'

# ------------------------------
# CREATE VIEW – Add a new collection entry
# ------------------------------
class CollectionCreateView(CreateView):
    model = WasteCollection  # Use the WasteCollection model
    form_class = WasteCollectionForm  # Django form to handle input
    template_name = 'recycling/collection_form.html'  # Form template
    success_url = reverse_lazy('collection_list')  # Redirect after successful save

# ------------------------------
# UPDATE VIEW – Edit an existing collection entry
# ------------------------------
class CollectionUpdateView(UpdateView):
    model = WasteCollection
    form_class = WasteCollectionForm
    template_name = 'recycling/collection_form.html'
    success_url = reverse_lazy('collection_list')

# ------------------------------
# DELETE VIEW – Confirm and delete a collection entry
# ------------------------------
class CollectionDeleteView(DeleteView):
    model = WasteCollection
    template_name = 'recycling/collection_confirm_delete.html'
    success_url = reverse_lazy('collection_list')  # Redirect after deletion
