from django import forms
from .models import WasteCollection

# --------------------------------------------
# Form for creating and updating WasteCollection entries
# Uses Django's ModelForm to automatically generate fields
# based on the WasteCollection model
# --------------------------------------------
class WasteCollectionForm(forms.ModelForm):
    class Meta:
        model = WasteCollection  # Link the form to the WasteCollection model

        # Fields from the model that will appear in the form
        fields = [
            'household_name', 
            'address', 
            'phone', 
            'waste_type',
            'weight_kg', 
            'collection_date', 
            'status', 
            'notes'
        ]

        # Custom widgets for specific fields to improve user experience
        widgets = {
            # Multi-line text area for the address
            'address': forms.Textarea(attrs={'rows': 3}),

            # Multi-line text area for optional notes
            'notes': forms.Textarea(attrs={'rows': 3}),

            # HTML5 date picker for selecting the collection date
            'collection_date': forms.DateInput(attrs={'type': 'date'}),
        }
