from django.urls import path
from . import views

# URL patterns for the Waste Collection app
urlpatterns = [

    # ------------------------------
    # Home page – List all collection requests
    # ------------------------------
    path('', 
         views.CollectionListView.as_view(), 
         name='collection_list'),

    # ------------------------------
    # Detail page – View a single collection record
    # <int:pk> captures the record's primary key
    # ------------------------------
    path('collection/<int:pk>/', 
         views.CollectionDetailView.as_view(), 
         name='collection_detail'),

    # ------------------------------
    # Create page – Add a new waste collection entry
    # ------------------------------
    path('collection/new/', 
         views.CollectionCreateView.as_view(), 
         name='collection_create'),

    # ------------------------------
    # Update page – Edit an existing collection entry
    # ------------------------------
    path('collection/<int:pk>/edit/', 
         views.CollectionUpdateView.as_view(), 
         name='collection_update'),

    # ------------------------------
    # Delete page – Remove a collection entry
    # ------------------------------
    path('collection/<int:pk>/delete/', 
         views.CollectionDeleteView.as_view(), 
         name='collection_delete'),
]
