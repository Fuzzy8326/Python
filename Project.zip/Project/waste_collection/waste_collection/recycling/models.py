# Import Django's model classes and timezone utilities
from django.db import models
from django.utils import timezone

# Define the WasteCollection model - represents a waste collection record in the database
class WasteCollection(models.Model):
    """
    Model to store waste collection information.
    Each instance represents one waste collection appointment.
    """
    
    # Define choices for waste types - these will appear as dropdown options
   
    WASTE_TYPES = [
        ('plastic', 'Plastic'),      # Plastic waste
        ('paper', 'Paper'),          # Paper and cardboard
        ('glass', 'Glass'),          # Glass bottles and containers
        ('metal', 'Metal'),          # Metal cans and items
        ('organic', 'Organic'),      # Food waste and organic matter
        ('electronic', 'Electronic'), # E-waste (computers, phones, etc.)
    ]
    
    # Define choices for collection status - tracks the workflow
    STATUS_CHOICES = [
        ('pending', 'Pending'),         # Scheduled but not yet collected
        ('collected', 'Collected'),     # Waste has been picked up
        ('processing', 'Processing'),   # Currently being processed
        ('completed', 'Completed'),     # Fully processed and completed
    ]
    
    # stores short text with maximum length
    # Used for household/family name
    household_name = models.CharField(max_length=200)
    
    #stores longer text without length limit
    # Used for full address with multiple lines
    address = models.TextField()
    
    #stores phone number as text (preserves formatting like +1-555-1234)
    phone = models.CharField(max_length=20)
    
    # creates a dropdown menu in forms
    # Stores the first value (e.g., 'plastic') but displays the second (e.g., 'Plastic')
    waste_type = models.CharField(max_length=20, choices=WASTE_TYPES)
    
   
    weight_kg = models.DecimalField(max_digits=6, decimal_places=2)
    
    # DateField: stores only the date (no time)
    # default=timezone.now: if no date provided, use current date
    collection_date = models.DateField(default=timezone.now)
    
    # CharField with choices and default value
    # default='pending': new records automatically get 'pending' status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # TextField for optional additional notes
    # blank=True: not required in forms
    # null=True: can be NULL in database
    notes = models.TextField(blank=True, null=True)
    
    # DateTimeField: stores date and time
    # auto_now_add=True: automatically set when record is created (never changes)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # DateTimeField with auto_now: updates every time record is saved
    # Tracks the last modification time
    updated_at = models.DateTimeField(auto_now=True)
    
    # Meta class: provides metadata options for the model
    class Meta:
        # ordering: default sort order when querying records
        # '-collection_date': newest collection dates first (- means descending)
        # '-created_at': if dates are equal, sort by creation time
        ordering = ['-collection_date', '-created_at']
    
    # String representation: how the object appears as text
    # Used in Django admin, dropdowns, and when printing the object
    def __str__(self):
        return f"{self.household_name} - {self.waste_type} - {self.collection_date}"
